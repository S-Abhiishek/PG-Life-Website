# PGlife_website
This website is built using HTML, CSS, JS and BOOTSTRAP. This website is used to search the PGs available in respective cities, it also allows users to create accounts and login with their credentials. It also shows amenities available in PG's
